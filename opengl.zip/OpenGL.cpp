/**
 * @file OpenGL.cpp
 * @author your name (zemingzeng@126.com)
 * @brief
 * @version 0.1
 * @date 2023-11-07
 *
 * @copyright Copyright (c) 2023
 *
 */
//https://registry.khronos.org/OpenGL/specs/gl/GLSLangSpec.4.60.pdf
#include "opengl/OpenGL.h"
#include "glad/glad.h"
#include "GLFW/glfw3.h"
#include "opengl/OpenGLGlobal.h"
// #include "gl3w/gl3w.h"
#include "Util.hpp"
#include "iostream"
#include "math.h"

// GLM 专门为opengl定制的数学库
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

// 图片加载库,和纹理处理相关
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

using namespace mingzz;

void LOGD(const char *loginfo)
{
    std::cout << std::endl;
    std::cout << "OpenGL Debug : " << loginfo << std::endl;
}

const char *triangleVertexShaderSourceCode =
    "#version 330 core\n"
    "layout (location = 0) in vec3 vertex;\n"
    "layout (location = 1) in vec3 vertexColor;\n"
    "layout (location = 2) in vec2 textureCoords;\n"
    "uniform mat4 modelMatrix;\n"
    "uniform mat4 cameraViewMatrix;\n"
    "uniform mat4 projectionMatrix;\n"
    "out vec3 fragColor;\n"
    "out vec2 fragTextureCoords;\n"
    "void main()\n"
    "{\n"
    "fragColor = vertexColor;\n"
    "fragTextureCoords = textureCoords;\n"
    "gl_Position = projectionMatrix * cameraViewMatrix * modelMatrix * vec4(vertex,1.0f);\n"
    "}";

const char *triangleFragmentShaderSourceCode =
    "#version 330 core\n"
    "out vec4 color;\n"
    "in vec3 fragColor;\n"
    "in vec2 fragTextureCoords;\n"
    "uniform vec4 timeColor;\n"
    "uniform sampler2D texture2D;\n"
    "void main()\n"
    "{\n"
    "color = texture(texture2D,fragTextureCoords);\n"
    //"color = timeColor;\n"
    //"color = vec4(fragColor,1.0f);\n"
    "}";

glm::vec3 trianglesPositions[] = {
    glm::vec3(0.0f, 0.0f, 0.0f),
    glm::vec3(2.0f, 5.0f, -15.0f),
    glm::vec3(-1.5f, -2.2f, -2.5f),
    glm::vec3(-3.8f, -2.0f, -12.3f),
    glm::vec3(2.4f, -0.4f, -3.5f),
    glm::vec3(-1.7f, 3.0f, -7.5f),
    glm::vec3(1.3f, -2.0f, -2.5f),
    glm::vec3(1.5f, 2.0f, -2.5f),
    glm::vec3(1.5f, 0.2f, -1.5f),
    glm::vec3(-1.3f, 1.0f, -1.5f)};

GLfloat triangleVertices[] = {
    // 0.0f, 1.2f, 0.0f /*vertex coords*/, 1.0f, 0.0f, 0.0f /*color coords*/, 0.0f, 0.0f,    /*texture coords*/
    // 0.04f, 0.0f, 2.9f /*vertex coords*/, 0.0f, 1.0f, 0.0f /*color coords*/, 0.5f, 0.0f,   /*texture coords*/
    // -0.04f, 0.0f, 2.9f /*vertex coords*/, 0.0f, 0.0f, 1.0f /*color coords*/, 0.25f, 0.5f, /*texture coords*/

    0.0f, 0.5f, 0.0f /*vertex coords*/, 1.0f, 0.0f, 0.0f /*color coords*/, 0.0f, 0.0f,     /*texture coords*/
    -0.5f, -0.5f, 0.5f /*vertex coords*/, 0.0f, 1.0f, 0.0f /*color coords*/, 0.5f, 0.0f,   /*texture coords*/
    -0.5f, -0.5f, -0.5f /*vertex coords*/, 0.0f, 0.0f, 1.0f /*color coords*/, 0.25f, 0.5f, /*texture coords*/
    0.0f, 0.5f, 0.0f /*vertex coords*/, 1.0f, 0.0f, 0.0f /*color coords*/, 0.0f, 0.0f,     /*texture coords*/
    -0.5f, -0.5f, 0.5f /*vertex coords*/, 0.0f, 1.0f, 0.0f /*color coords*/, 0.5f, 0.0f,   /*texture coords*/
    0.5f, -0.5f, 0.5f /*vertex coords*/, 0.0f, 0.0f, 1.0f /*color coords*/, 0.25f, 0.5f,   /*texture coords*/
    0.0f, 0.5f, 0.0f /*vertex coords*/, 1.0f, 0.0f, 0.0f /*color coords*/, 0.0f, 0.0f,     /*texture coords*/
    0.5f, -0.5f, 0.5f /*vertex coords*/, 0.0f, 1.0f, 0.0f /*color coords*/, 0.5f, 0.0f,    /*texture coords*/
    0.5f, -0.5f, -0.5f /*vertex coords*/, 0.0f, 0.0f, 1.0f /*color coords*/, 0.25f, 0.5f,  /*texture coords*/
    0.0f, 0.5f, 0.0f /*vertex coords*/, 1.0f, 0.0f, 0.0f /*color coords*/, 0.0f, 0.0f,     /*texture coords*/
    0.5f, -0.5f, -0.5f /*vertex coords*/, 0.0f, 1.0f, 0.0f /*color coords*/, 0.5f, 0.0f,   /*texture coords*/
    -0.5f, -0.5f, -0.5f /*vertex coords*/, 0.0f, 0.0f, 1.0f /*color coords*/, 0.25f, 0.5f, /*texture coords*/
    0.5f, -0.5f, -0.5f /*vertex coords*/, 1.0f, 0.0f, 0.0f /*color coords*/, 0.0f, 0.0f,   /*texture coords*/
    -0.5f, -0.5f, -0.5f /*vertex coords*/, 0.0f, 1.0f, 0.0f /*color coords*/, 0.5f, 0.0f,  /*texture coords*/
    -0.5f, -0.5f, 0.5f /*vertex coords*/, 0.0f, 0.0f, 1.0f /*color coords*/, 0.25f, 0.5f,  /*texture coords*/
    -0.5f, -0.5f, 0.5f /*vertex coords*/, 1.0f, 0.0f, 0.0f /*color coords*/, 0.0f, 0.0f,   /*texture coords*/
    0.5f, -0.5f, 0.5f /*vertex coords*/, 0.0f, 1.0f, 0.0f /*color coords*/, 0.5f, 0.0f,    /*texture coords*/
    0.5f, -0.5f, -0.5f /*vertex coords*/, 0.0f, 0.0f, 1.0f /*color coords*/, 0.25f, 0.5f   /*texture coords*/

};

GLuint rectangleIndexOrder[] = {
    0, 1, 2,
    0, 3, 2};

GLfloat cubeVertices[] = {
    -0.5f, -0.5f, -0.5f, 0.0f, 0.0f, -1.0f,
    0.5f, -0.5f, -0.5f, 0.0f, 0.0f, -1.0f,
    0.5f, 0.5f, -0.5f, 0.0f, 0.0f, -1.0f,
    0.5f, 0.5f, -0.5f, 0.0f, 0.0f, -1.0f,
    -0.5f, 0.5f, -0.5f, 0.0f, 0.0f, -1.0f,
    -0.5f, -0.5f, -0.5f, 0.0f, 0.0f, -1.0f,

    -0.5f, -0.5f, 0.5f, 0.0f, 0.0f, 1.0f,
    0.5f, -0.5f, 0.5f, 0.0f, 0.0f, 1.0f,
    0.5f, 0.5f, 0.5f, 0.0f, 0.0f, 1.0f,
    0.5f, 0.5f, 0.5f, 0.0f, 0.0f, 1.0f,
    -0.5f, 0.5f, 0.5f, 0.0f, 0.0f, 1.0f,
    -0.5f, -0.5f, 0.5f, 0.0f, 0.0f, 1.0f,

    -0.5f, 0.5f, 0.5f, -1.0f, 0.0f, 0.0f,
    -0.5f, 0.5f, -0.5f, -1.0f, 0.0f, 0.0f,
    -0.5f, -0.5f, -0.5f, -1.0f, 0.0f, 0.0f,
    -0.5f, -0.5f, -0.5f, -1.0f, 0.0f, 0.0f,
    -0.5f, -0.5f, 0.5f, -1.0f, 0.0f, 0.0f,
    -0.5f, 0.5f, 0.5f, -1.0f, 0.0f, 0.0f,

    0.5f, 0.5f, 0.5f, 1.0f, 0.0f, 0.0f,
    0.5f, 0.5f, -0.5f, 1.0f, 0.0f, 0.0f,
    0.5f, -0.5f, -0.5f, 1.0f, 0.0f, 0.0f,
    0.5f, -0.5f, -0.5f, 1.0f, 0.0f, 0.0f,
    0.5f, -0.5f, 0.5f, 1.0f, 0.0f, 0.0f,
    0.5f, 0.5f, 0.5f, 1.0f, 0.0f, 0.0f,

    -0.5f, -0.5f, -0.5f, 0.0f, -1.0f, 0.0f,
    0.5f, -0.5f, -0.5f, 0.0f, -1.0f, 0.0f,
    0.5f, -0.5f, 0.5f, 0.0f, -1.0f, 0.0f,
    0.5f, -0.5f, 0.5f, 0.0f, -1.0f, 0.0f,
    -0.5f, -0.5f, 0.5f, 0.0f, -1.0f, 0.0f,
    -0.5f, -0.5f, -0.5f, 0.0f, -1.0f, 0.0f,

    -0.5f, 0.5f, -0.5f, 0.0f, 1.0f, 0.0f,
    0.5f, 0.5f, -0.5f, 0.0f, 1.0f, 0.0f,
    0.5f, 0.5f, 0.5f, 0.0f, 1.0f, 0.0f,
    0.5f, 0.5f, 0.5f, 0.0f, 1.0f, 0.0f,
    -0.5f, 0.5f, 0.5f, 0.0f, 1.0f, 0.0f,
    -0.5f, 0.5f, -0.5f, 0.0f, 1.0f, 0.0f};

// reflect函数第一个参数是（从光源指向片段位置的向量）
// 第二个参数要求是一个法向量
const char *cubeVertexShaderSourceCode =
    "#version 330 core\n"
    "layout (location = 0) in vec3 vertex;\n"
    "layout (location = 1) in vec3 normalVector;\n"
    "out vec3 fragmentPosition;\n" // 在世界坐标系中每个顶点的坐标
    "out vec3 normalVector_;\n"    // 法向量给到fragment shader
    "uniform mat4 modelMatrix;\n"
    "uniform mat4 cameraViewMatrix;\n"
    "uniform mat4 projectionMatrix;\n"
    "void main()\n"
    "{\n"
    "normalVector_ = normalVector;\n"
    "fragmentPosition =  vec3(modelMatrix * vec4(vertex,1.0f));\n"
    "gl_Position = projectionMatrix * cameraViewMatrix * vec4(fragmentPosition,1.0f);\n"
    "}";

const char *cubeFragmentShaderSourceCode =
    "#version 330 core\n"
    "struct Material {\n"
    "vec3 ambient;\n"
    "vec3 diffuse;\n"
    "vec3 specular;\n"
    "float shininess;\n"
    "};\n"
    "struct Light {\n"
    "vec3 ambient;\n"
    "vec3 diffuse;\n"
    "vec3 specular;\n"
    "vec3 position;\n"
    "vec3 color;\n"
    "};\n"
    "out vec4 fragmentColor;\n"
    "in vec3 fragmentPosition;\n"
    "in vec3 normalVector_;\n"
    "uniform vec3 objectColor;\n"
    "uniform vec3 cameraPosition;\n"
    "uniform Material material;\n"
    "uniform Light light;\n"
    "void main()\n"
    "{\n"
    // 单位法向量
    "vec3 normalVector = normalize(normalVector_);\n"
    // 光射向顶点的单位向量
    "vec3 lightVector = normalize(light.position - fragmentPosition);\n"
    // 环境光强度
    //"float ambientStrength = 0.1f;\n"
    "vec3  ambinetColor = light.ambient * material.ambient * light.color;\n"
    // 漫反射
    // 夹角大于90，算出来是负的
    "vec3 diffuseColor = (max(dot(lightVector , normalVector), 0.0)) * light.color;\n"
    "diffuseColor =  light.diffuse * material.diffuse * diffuseColor;\n"
    // 镜面光照
    // 镜面光照强度
    // 算出反射光向量
    "vec3 reflectVector = reflect(-lightVector, normalVector);\n"
    "vec3 cameraVector = normalize(cameraPosition - fragmentPosition);\n"
    // 高光反光度，越高物体反光度越强(32默认)
    "vec3 specularColor = light.specular * material.specular * (pow(max(dot(reflectVector, cameraVector), 0.0f), material.shininess)) * light.color;\n"

    // (环境光 + 漫反射 + 镜面光照) 加上材料属性最后输出最终的颜色
    "fragmentColor = vec4(diffuseColor + ambinetColor + specularColor, 1.0f);\n"
    "}";

const char *cubeLightVertexShaderSourceCode =
    "#version 330 core\n"
    "layout (location = 0) in vec3 vertex;\n"
    "uniform mat4 modelMatrix;\n"
    "uniform mat4 cameraViewMatrix;\n"
    "uniform mat4 projectionMatrix;\n"
    "void main()\n"
    "{\n"
    "gl_Position = projectionMatrix * cameraViewMatrix * modelMatrix * vec4(vertex,1.0f);\n"
    "}";
const char *cubeLightFragmentShaderSourceCode =
    "#version 330 core\n"
    "out vec4 color;\n"
    "uniform vec3 lightColor;\n"
    "void main()\n"
    "{\n"
    "color = vec4(lightColor, 1.0f);\n"
    "}";

// 材料对应的4种属性
glm::vec3 materailAmbient(1.0f, 0.5f, 0.31f);
glm::vec3 materailDiffuse(1.0f, 0.5f, 0.31f);
glm::vec3 materailSpecular(0.5f, 0.5f, 0.5f);
float materialShininess = 32.0f;

// 3种光照强度
glm::vec3 lightAmbient(0.2f, 0.2f, 0.2f);
glm::vec3 lightDiffuse(0.5f, 0.5f, 0.5f);
glm::vec3 lightSpecular(1.0f, 1.0f, 1.0f);
glm::vec3 lightPosition(1.0f, 1.0f, -0.5f);
glm::vec3 lightColor(1.0f, 1.0f, 1.0f);

glm::vec3 cameraPosition(0.0f, 0.0f, 4.0f);
glm::vec3 cameraUP(0.0f, 1.0f, 0.0f);
glm::vec3 cameraFront(0.0f, 0.0f, -1.0f);
float cameraSpeed = 0.02f;

float Yaw = -90.0f;
float Pitch = 0.0f;
float lastMouseX = 0.0f;
float lastMouseY = 0.0f;
bool firstGetMouseXY = true;

float Fov = 45.0f;
float maxFov = 80.0f;
float minFov = 1.0f;

void windowSizeChangedCallback(GLFWwindow *window, int w, int h);

void processKeyboardInput(GLFWwindow *window);

void mouseMoveCallback(GLFWwindow *window, double xPos, double yPos);

void mouseScrollCallback(GLFWwindow *window, double x, double y);

void OpenGL::glmTest()
{
    glm::mat4 trans(1.0f);
    Util::LOGD("glmTest trans length:%zu", trans.length());
    Util::LOGD("glmTest trans length:%f", trans[3][2]);
    glm::vec4 vec(3.0f, 1.0f, 0.0f, 1.0f);
    // x平移1 y平移1
    trans = glm::translate(trans, glm::vec3(1.0f, 1.0f, 0.0f));
    // 平移矩阵
    vec = trans * vec;
    Util::LOGD("glmTest vec:%f  %f %f %f", vec[0], vec[1], vec[2], vec[3]);

    // 透视矩阵
    glm::mat4 projectionMatrix(1.0f);
    // projectionMatrix = glm::perspective(glm::radians(45.0f),
    //                                     (float)(opengl::WINDOW_WIDTH / opengl::WINDOW_HEIGHT),
    //                                     0.1f, 100.0f);
    glm::vec4 vertext1(0.0f, 1.2f, 0.0f, 1.0f);
    glm::vec4 vertext2(0.04f, 0.0f, 2.9f, 1.0f);
    glm::vec4 vertext3(-0.04f, 0.0f, 2.9f, 1.0f);
    glm::mat4 modelMatrix(1.0f);
    // modelMatrix = glm::translate(modelMatrix, glm::vec3(0.0f,
    //                                                     0.0f,
    //                                                     -3.0f));
    modelMatrix = glm::rotate(modelMatrix,
                              glm::radians(90.0f),
                              glm::vec3(0.0f, 1.0f, 0.0f));
    // modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 1.0f, 1.0f));
    glm::vec4 ndc1 = projectionMatrix * modelMatrix * vertext1;
    glm::vec4 ndc2 = projectionMatrix * modelMatrix * vertext2;
    glm::vec4 ndc3 = projectionMatrix * modelMatrix * vertext3;
    Util::LOGD("ndc1(/w): %f  %f  %f  %f", ndc1[0] / ndc1[3], ndc1[1] / ndc1[3], ndc1[2] / ndc1[3], ndc1[3]);
    Util::LOGD("ndc2(/w): %f  %f  %f  %f", ndc2[0] / ndc2[3], ndc2[1] / ndc2[3], ndc2[2] / ndc2[3], ndc2[3]);
    Util::LOGD("ndc3(/w): %f  %f  %f  %f", ndc3[0] / ndc3[3], ndc3[1] / ndc3[3], ndc3[2] / ndc3[3], ndc3[3]);
}

void OpenGL::start()
{
    LOGD("start()");

    // opengl start!!

    // init glfw library and init glfw settings
    int ret = glfwInit();
    LOGD(GLFW_TRUE == ret ? "glfw init success" : "glfw init fail");
    if (GLFW_TRUE != ret)
    {
        glfwTerminate();
        return;
    }

    // configure the options prefixed with GLFW_
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // create window
    // also createsanOpenGL context that isassociated with that window
    GLFWwindow *glfwWindow = glfwCreateWindow(opengl::WINDOW_WIDTH, opengl::WINDOW_HEIGHT,
                                              "OpenGL Learning..", nullptr, nullptr);
    LOGD(glfwWindow ? "glfwWindow create success" : "glfwWindow create fail");
    if (!glfwWindow)
    {
        glfwTerminate();
        return;
    }

    // tell GLFW to make the context of our window the main context on the current threaed
    glfwMakeContextCurrent(glfwWindow);

    // initialize glad
    // load the address of the OpenGL function pointers
    ret = gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);
    Util::LOGD("gladLoadGLLoader ret:%d", ret);
    if (!ret)
    {
        LOGD("gladLoadGLLoader failed!!");
        return;
    }

    // (0,0)lower left location
    glViewport(0, 0, opengl::WINDOW_WIDTH, opengl::WINDOW_HEIGHT);

    // 窗口宽高变化回调
    glfwSetFramebufferSizeCallback(glfwWindow, windowSizeChangedCallback);

    // 鼠标移动坐标回调
    glfwSetCursorPosCallback(glfwWindow, mouseMoveCallback);

    // 鼠标滑轮滚动的回调
    glfwSetScrollCallback(glfwWindow, mouseScrollCallback);

    // configure global opengl state
    glEnable(GL_DEPTH_TEST);

    glfwSetInputMode(glfwWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // vertex shader
    // Util::LOGD("triangleVertexShaderSourceCode:\n%s", triangleVertexShaderSourceCode);
    unsigned int triangleVertexShader;
    triangleVertexShader = glCreateShader(GL_VERTEX_SHADER);
    Util::LOGD("triangleVertexShader:%d", triangleVertexShader);
    glShaderSource(triangleVertexShader, 1, &triangleVertexShaderSourceCode, nullptr);
    glCompileShader(triangleVertexShader);
    // check compile result
    int result;
    char infoLog[1024];
    infoLog[1023] = '\0';
    glGetShaderiv(triangleVertexShader, GL_COMPILE_STATUS, &result);
    if (!result)
    {
        glGetShaderInfoLog(triangleVertexShader, 1024, nullptr, infoLog);
        Util::LOGD("triangle vertex shader source code compile fail:%s", infoLog);
        glfwTerminate();
        return;
    }

    // fragment shader
    // Util::LOGD("triangleFragmentShaderSourceCode:\n%s", triangleFragmentShaderSourceCode);
    unsigned int triangleFragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(triangleFragmentShader, 1, &triangleFragmentShaderSourceCode, nullptr);
    glCompileShader(triangleFragmentShader);
    glGetShaderiv(triangleFragmentShader, GL_COMPILE_STATUS, &result);
    if (!result)
    {
        glGetShaderInfoLog(triangleFragmentShader, 1024, nullptr, infoLog);
        Util::LOGD("triangle fragment shader source code compile fail:%s", infoLog);
        glfwTerminate();
        return;
    }

    // shader program
    unsigned int shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, triangleVertexShader);
    glAttachShader(shaderProgram, triangleFragmentShader);
    glLinkProgram(shaderProgram);
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &result);
    if (!result)
    {
        glGetProgramInfoLog(shaderProgram, 1024, nullptr, infoLog);
        Util::LOGD("shader program link fail:%s", infoLog);
        glfwSetWindowShouldClose(glfwWindow, true);
    }
    glDeleteShader(triangleVertexShader);
    glDeleteShader(triangleFragmentShader);

    // cube shader
    unsigned int cubeVertexShader;
    cubeVertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(cubeVertexShader, 1, &cubeVertexShaderSourceCode, nullptr);
    glCompileShader(cubeVertexShader);
    unsigned int cubeFragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(cubeFragmentShader, 1, &cubeFragmentShaderSourceCode, nullptr);
    glCompileShader(cubeFragmentShader);
    // shader program
    unsigned int cubeShaderProgram = glCreateProgram();
    glAttachShader(cubeShaderProgram, cubeVertexShader);
    glAttachShader(cubeShaderProgram, cubeFragmentShader);
    glLinkProgram(cubeShaderProgram);

    glDeleteShader(cubeVertexShader);
    glDeleteShader(cubeFragmentShader);

    unsigned int cubeLightVertexShader;
    cubeLightVertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(cubeLightVertexShader, 1, &cubeLightVertexShaderSourceCode, nullptr);
    glCompileShader(cubeLightVertexShader);
    unsigned int cubeLightFragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(cubeLightFragmentShader, 1, &cubeLightFragmentShaderSourceCode, nullptr);
    glCompileShader(cubeLightFragmentShader);
    // shader program
    unsigned int cubeLightShaderProgram = glCreateProgram();
    glAttachShader(cubeLightShaderProgram, cubeLightVertexShader);
    glAttachShader(cubeLightShaderProgram, cubeLightFragmentShader);
    glLinkProgram(cubeLightShaderProgram);

    glDeleteShader(cubeLightVertexShader);
    glDeleteShader(cubeLightFragmentShader);

    // cube VBO VAO
    unsigned int cubeVAO,
        cubeVBO,
        cubeLightVAO,
        cubeLightVBO;
    glGenBuffers(1, &cubeVBO);
    glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(cubeVertices), cubeVertices, GL_STATIC_DRAW);
    glGenVertexArrays(1, &cubeVAO);
    glBindVertexArray(cubeVAO);
    glVertexAttribPointer(0,
                          3,
                          GL_FLOAT,
                          GL_FALSE,
                          6 * sizeof(float),
                          (void *)(0));
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1,
                          3,
                          GL_FLOAT,
                          GL_FALSE,
                          6 * sizeof(float),
                          (void *)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);
    cubeLightVAO = cubeVAO;
    cubeLightVBO = cubeLightVBO;

    int jpgW,
        jpgH,
        jpgColorChannelCount;
    std::string jpgPath("C:\\Users\\zemizeng\\temp\\apps\\VSCode\\projects\\OpenGLLearning\\src\\fenjing.jpg");
    GLubyte *jpgData = stbi_load(jpgPath.c_str(),
                                 &jpgW, &jpgH,
                                 &jpgColorChannelCount, 0);
    Util::LOGD("jpg path:%s\njpg W:%d,H:%d,colorChannelCount:%d",
               jpgPath.c_str(), jpgW, jpgH, jpgColorChannelCount);

    // texture
    GLuint texture2D;
    glGenTextures(1, &texture2D);
    Util::LOGD("glGenTextures texture2D:%d", texture2D);
    glBindTexture(GL_TEXTURE_2D, texture2D);
    // wrapping
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    // filtering
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // mipmap
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);

    if (jpgData)
    {
        Util::LOGD("glGenerateMipmap!!!!!!");
        glTexImage2D(
            GL_TEXTURE_2D, 0 /*mipmap level*/, /*GPU*/ GL_RGB,
            jpgW, jpgH, 0,
            /*CPU*/ GL_RGB, GL_UNSIGNED_BYTE,
            jpgData /*jpg data*/);
        glGenerateMipmap(GL_TEXTURE_2D);
    }
    else
    {
        Util::LOGD("stbi_load image failed!!!");
    }

    // free jpg data
    stbi_image_free(jpgData);

    unsigned int VBO;
    unsigned int VAO;
    unsigned int EBO;
    glGenVertexArrays(1, &VAO);
    Util::LOGD("glCreateVertexArrays VAO:%d", VAO);
    glBindVertexArray(VAO);
    // 生成vbo buffer
    glGenBuffers(1, &VBO);
    Util::LOGD("glGenBuffers VBO:%d", VBO);
    // 绑定vbo，可以理解为声明上面生成的buffer是用来干嘛的
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    // 填充这个buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(triangleVertices), triangleVertices, GL_STATIC_DRAW);
    glGenBuffers(1, &EBO);
    Util::LOGD("glGenBuffers EBO:%d", EBO);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(rectangleIndexOrder),
                 rectangleIndexOrder, GL_STATIC_DRAW);

    // 设置attrubite
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE,
                          8 * sizeof(GLfloat), (void *)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE,
                          8 * sizeof(GLfloat), (void *)(3 * sizeof(GLfloat)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 3, GL_FLOAT, GL_FALSE,
                          8 * sizeof(GLfloat), (void *)(6 * sizeof(GLfloat)));
    glEnableVertexAttribArray(2);

    // unbind 需要时再bind
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    glBindTexture(GL_TEXTURE_2D, 0);

    while (!glfwWindowShouldClose(glfwWindow))
    {
        // Util::LOGD("render loop!");
        processKeyboardInput(glfwWindow);

        // RGBA
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glUseProgram(shaderProgram);
        glBindTexture(GL_TEXTURE_2D, texture2D);
        // default is:
        // glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
        // glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        glBindVertexArray(VAO);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);

        GLfloat time = glfwGetTime();
        GLfloat color = (sin(time) / 2.0f) + 0.5f;
        GLint timeColorLocation = glGetUniformLocation(shaderProgram, "timeColor");
        glUniform4f(timeColorLocation, 0.0f, color, 0.0f, 1.0f);

        // 透视矩阵
        glm::mat4 projectionMatrix(1.0f);
        projectionMatrix =
            glm::perspective(glm::radians(Fov),
                             (float)(opengl::WINDOW_WIDTH / opengl::WINDOW_HEIGHT),
                             0.1f, 100.0f);
        GLint projectionMatrixLocation =
            glGetUniformLocation(shaderProgram, "projectionMatrix");
        glUniformMatrix4fv(projectionMatrixLocation,
                           1,
                           GL_FALSE,
                           &projectionMatrix[0][0]);

        // camera view matrix
        glm::mat4 cameraViewMatrix(1.0f);
        float radius = 10.0f;
        float cameraX = static_cast<float>(sin(glfwGetTime()) * radius);
        float cameraZ = static_cast<float>(cos(glfwGetTime()) * radius);
        // cameraViewMatrix = glm::lookAt(
        //     glm::vec3(cameraX, 0.0f, cameraZ),
        //     glm::vec3(0.0f, 0.0f, 0.0f),
        //     glm::vec3(0.0f, 1.0f, 0.0f) /*固定默认值*/);
        cameraViewMatrix = glm::lookAt(
            cameraPosition,
            cameraPosition + cameraFront,
            cameraUP);
        GLint cameraViewMatrixLocation =
            glGetUniformLocation(shaderProgram, "cameraViewMatrix");
        glUniformMatrix4fv(cameraViewMatrixLocation,
                           1,
                           GL_FALSE,
                           &cameraViewMatrix[0][0]);

        glm::mat4 modelMatrix(1.0f);
        for (int i = 0; i < sizeof(trianglesPositions) / sizeof(glm::vec3); ++i)
        {
            modelMatrix = glm::mat4(1.0f);
            modelMatrix = glm::translate(modelMatrix, trianglesPositions[i]);
            float angle = 20.0f * i;
            modelMatrix = glm::rotate(modelMatrix,
                                      //   glm::radians(angle) * (float)glfwGetTime(),
                                      glm::radians(angle),
                                      glm::vec3(1.0f, 0.3f, 0.5f));
            // modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 1.0f, 1.0f));
            GLint modelMatrixLocation = glGetUniformLocation(shaderProgram, "modelMatrix");
            glUniformMatrix4fv(modelMatrixLocation,
                               1,
                               GL_FALSE,
                               glm::value_ptr(modelMatrix));

            // glDrawArrays(GL_TRIANGLES, 0, 18);
        }
        // glPointSize(10.0f);
        // glDrawArrays(GL_POINTS, 0, 3);

        // glDrawArrays(GL_LINES, 0, 3);

        // glDrawElements(GL_TRIANGLES, sizeof(rectangleIndexOrder),
        //                GL_UNSIGNED_INT, (void *)0);

        // light study
        // 环境光强度

        glUseProgram(cubeLightShaderProgram);
        glBindVertexArray(cubeLightVAO);

        glUniform3f(glGetUniformLocation(cubeLightShaderProgram, "lightColor"),
                    lightColor.r,
                    lightColor.g,
                    lightColor.b);
        float time_ = (float)glfwGetTime();

        glm::mat4 cubeLightModelMatrix = glm::rotate(glm::mat4(1.0f),
                                                     glm::radians(time_ * 40.0f),
                                                     glm::vec3(0.0f, 1.0f, 1.0f));
        cubeLightModelMatrix = glm::translate(cubeLightModelMatrix,
                                              glm::vec3(0.0f, 0.0f, 0.5f + 0.1f + 1.0f));
        cubeLightModelMatrix = glm::rotate(cubeLightModelMatrix,
                                           glm::radians(20.0f),
                                           glm::vec3(1.0f, 0.0f, 0.0f));
        cubeLightModelMatrix = glm::rotate(cubeLightModelMatrix,
                                           glm::radians(-20.0f),
                                           glm::vec3(0.0f, 1.0f, 0.0f));
        cubeLightModelMatrix = glm::scale(cubeLightModelMatrix,
                                          glm::vec3(0.2f, 0.2f, 0.2f));
        lightPosition = glm::vec3(cubeLightModelMatrix * glm::vec4(lightPosition, 1.0f));

        glm::mat4 cubeLightCameraViewMatrix = cameraViewMatrix;
        glm::mat4 cubeLightProjectionMatrix = projectionMatrix;
        glUniformMatrix4fv(glGetUniformLocation(cubeLightShaderProgram, "modelMatrix"),
                           1,
                           GL_FALSE,
                           glm::value_ptr(cubeLightModelMatrix));
        glUniformMatrix4fv(glGetUniformLocation(cubeLightShaderProgram, "cameraViewMatrix"),
                           1,
                           GL_FALSE,
                           glm::value_ptr(cubeLightCameraViewMatrix));
        glUniformMatrix4fv(glGetUniformLocation(cubeLightShaderProgram, "projectionMatrix"),
                           1,
                           GL_FALSE,
                           glm::value_ptr(cubeLightProjectionMatrix));

        glDrawArrays(GL_TRIANGLES, 0, 36);

        glUseProgram(cubeShaderProgram);
        glBindVertexArray(cubeVAO);

        // 设置材料属性 (青塑料) 材料表：http://devernay.free.fr/cours/opengl/materials.html
        materailAmbient = glm::vec3(0.0f, 0.1f, 0.06f);
        materailDiffuse = glm::vec3(0.0f, 0.50980392f, 0.50980392f);
        materailSpecular = glm::vec3(0.50196078f, 0.50196078f, 0.50196078f);
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "material.ambient"), 1,
                     &materailAmbient[0]);
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "material.diffuse"), 1,
                     &materailDiffuse[0]);
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "material.specular"), 1,
                     &materailSpecular[0]);
        glUniform1f(glGetUniformLocation(cubeShaderProgram, "material.shininess"),
                    materialShininess);

        // 设置光照属性
        lightAmbient = glm::vec3(1.0f, 1.0f, 1.0f);
        lightDiffuse = glm::vec3(1.0f, 1.0f, 1.0f);
        lightSpecular = glm::vec3(1.0f, 1.0f, 1.0f);
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "light.ambient"), 1,
                     &lightAmbient[0]);
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "light.diffuse"), 1,
                     &lightDiffuse[0]);
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "light.specular"), 1,
                     &lightSpecular[0]);
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "light.position"), 1,
                     glm::value_ptr(lightPosition));
        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "light.color"), 1,
                     &lightColor[0]);

        glUniform3fv(glGetUniformLocation(cubeShaderProgram, "cameraPosition"),
                     1, glm::value_ptr(cameraPosition));

        glUniform3f(glGetUniformLocation(cubeShaderProgram, "objectColor"),
                    1.0f, 0.5f, 0.31f);
        glm::mat4 cubeModelMatrix = glm::rotate(glm::mat4(1.0f),
                                                glm::radians(15.0f),
                                                glm::vec3(1.0f, 0.0f, 0.0f));
        cubeModelMatrix = glm::rotate(cubeModelMatrix,
                                      glm::radians(-10.0f),
                                      glm::vec3(0.0f, 1.0f, 0.0f));
        glm::mat4 cubeCameraViewMatrix = cameraViewMatrix;
        glm::mat4 cubeProjectionMatrix = projectionMatrix;
        glUniformMatrix4fv(glGetUniformLocation(cubeShaderProgram, "modelMatrix"),
                           1,
                           GL_FALSE,
                           glm::value_ptr(cubeModelMatrix));
        glUniformMatrix4fv(glGetUniformLocation(cubeShaderProgram, "cameraViewMatrix"),
                           1,
                           GL_FALSE,
                           glm::value_ptr(cubeCameraViewMatrix));
        glUniformMatrix4fv(glGetUniformLocation(cubeShaderProgram, "projectionMatrix"),
                           1,
                           GL_FALSE,
                           glm::value_ptr(cubeProjectionMatrix));
        glDrawArrays(GL_TRIANGLES, 0, 36);

        glBindVertexArray(0);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

        glfwSwapBuffers(glfwWindow);
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteVertexArrays(1, &cubeVAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &cubeVBO);
    glDeleteBuffers(1, &EBO);
    glDeleteProgram(shaderProgram);
    glDeleteProgram(cubeShaderProgram);

    // frees any other allocated resource
    glfwTerminate();
}

OpenGL::~OpenGL()
{
}

void windowSizeChangedCallback(GLFWwindow *window, int w, int h)
{
    Util::LOGD("windowSizeChangedCallback w:%d,h:%d", w, h);
    glViewport(0, 0, w, h);
}

void processKeyboardInput(GLFWwindow *window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        Util::LOGD("GLFW_KEY_ESCAPE GLFW_PRESS!");
        glfwSetWindowShouldClose(window, true);
    }
    else if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
    {
        Util::LOGD("GLFW_KEY_W GLFW_PRESS!");
        cameraPosition += cameraSpeed * cameraFront;
    }
    else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
    {
        Util::LOGD("GLFW_KEY_S GLFW_PRESS!");
        cameraPosition -= cameraSpeed * cameraFront;
    }
    else if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
    {
        Util::LOGD("GLFW_KEY_A GLFW_PRESS!");
        cameraPosition += glm::vec3(-1.0f, 0.0f, 0.0f) * cameraSpeed;
    }
    else if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
    {
        Util::LOGD("GLFW_KEY_D GLFW_PRESS!");
        cameraPosition += glm::vec3(1.0f, 0.0f, 0.0f) * cameraSpeed;
    }
}

void mouseMoveCallback(GLFWwindow *window, double xPos, double yPos)
{
    Util::LOGD("mouseMoveCallback current X:%f  Y:%f sin(glm::radians(90.0f)):%f",
               xPos,
               yPos,
               sin(glm::radians(90.0f)));
    if (firstGetMouseXY)
    {
        lastMouseX = xPos;
        lastMouseY = yPos;
        firstGetMouseXY = false;
    }

    float rotateSpeed = 0.03f;

    float xOffset = xPos - lastMouseX;
    Yaw += (xOffset * rotateSpeed);

    float yOffset = lastMouseY - yPos;
    Pitch += (yOffset * rotateSpeed);
    Pitch = Pitch > 89.0f ? 89.0f : Pitch;
    Pitch = Pitch < -89.0f ? -89.0f : Pitch;

    // front是指向camera的z轴正方向的单位向量
    glm::vec3 front;
    front.x = cos(glm::radians(Yaw)) * cos(glm::radians(Pitch));
    front.y = sin(glm::radians(Pitch));
    front.z = sin(glm::radians(Yaw)) * cos(glm::radians(Pitch));

    // cameraFront = glm::normalize(front);
    // cameraFront = front;
    lastMouseX = xPos;
    lastMouseY = yPos;
    Util::LOGD("mouseMoveCallback cameraFront x:%f y:%f z:%f x^2+y^2+z^2=%f",
               cameraFront.x,
               cameraFront.y,
               cameraFront.z,
               cameraFront.x * cameraFront.x +
                   cameraFront.y * cameraFront.y +
                   cameraFront.z * cameraFront.z);
    // Util::LOGD("mouseMoveCallback front x:%f y:%f z:%f x^2+y^2+z^2=%f",
    //            front.x,
    //            front.y,
    //            front.z,
    //            front.x * front.x + front.y * front.y + front.z * front.z);
}

void mouseScrollCallback(GLFWwindow *window, double xOffset, double yOffset)
{
    Util::LOGD("mouseScrollCallback  xOffset:%f yOffset:%f ", xOffset, yOffset);
    if (Fov >= minFov && Fov <= maxFov)
    {
        Fov -= yOffset;
    }
    Fov = Fov < minFov ? minFov : (Fov > maxFov ? maxFov : Fov);
    Util::LOGD("mouseScrollCallback FOV:%f", Fov);
}